// console.log(new Date().toDateString())
// console.log(new Date().toTimeString())
// console.log(new Date().toUTCString())
//
// const t = new Date(Date.now()).toISOString();
// console.log(t);
//
// console.log(new Date(Date.now()).toUTCString())
console.log(new Date(Date.now()))